# Programming Learning (Expo SDK 58, React Native, Android)

## Set up
1. Create a fresh SDK 58 project (this pins every package to the right version):
   npx create-expo-app@latest ProgrammingLearning
   cd ProgrammingLearning
2. Delete the template's `app/` and `src/` (and `components/`, `hooks/`, `constants/` if present),
   then copy this folder's `app/`, `src/` and `app.json` into the project
   (keep the `name`/`slug` you like).
3. Install the two extra packages:
   npx expo install @react-native-async-storage/async-storage expo-crypto
4. Run on Android:
   npx expo start --android
   If the store version of Expo Go does not support SDK 58 yet, use a development build instead:
   npx expo run:android

## Built-in admin
Email: admin@programming.edu   Password: Admin@123
(Change in `src/auth/AuthContext.tsx` -> BUILT_IN_ADMIN.)

## Rules (src/rules.ts)
- Only Teacher and Student can be chosen at registration; Admin can never be registered.
- Registration rules: name 2+ chars, valid email, password 8+ with a letter and a number, passwords match, role chosen, email not already used.
- After login, each role is sent to its own screen (/admin, /teacher, /student), and the other roles' screens are blocked by route guards in `app/_layout.tsx`.

## Note
Accounts are stored on the device (AsyncStorage) with hashed passwords. This is fine for a prototype;
for real use, move accounts to a backend (Firebase, Supabase, or your own API).
