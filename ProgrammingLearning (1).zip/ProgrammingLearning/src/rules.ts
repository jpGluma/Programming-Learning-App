// Rule-based access: every rule about roles and registration lives here.

export type Role = 'admin' | 'teacher' | 'student';

// Admin is built into the system, so it can never be chosen at registration.
export const REGISTRABLE_ROLES = ['teacher', 'student'] as const;
export type RegistrableRole = (typeof REGISTRABLE_ROLES)[number];

export const ROLE_LABEL: Record<Role, string> = {
  admin: 'Admin',
  teacher: 'Teacher',
  student: 'Student',
};

// Rule: each role lands on its own home screen after login.
export const ROLE_HOME = {
  admin: '/admin',
  teacher: '/teacher',
  student: '/student',
} as const;

export type RegisterInput = {
  name: string;
  email: string;
  password: string;
  confirm: string;
  role: RegistrableRole | null;
};

export type RegisterErrors = Partial<Record<keyof RegisterInput, string>>;

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;

export function isValidEmail(email: string) {
  return EMAIL_RE.test(email.trim());
}

export function validateRegistration(input: RegisterInput): RegisterErrors {
  const errors: RegisterErrors = {};

  if (input.name.trim().length < 2) {
    errors.name = 'Enter your full name (at least 2 characters).';
  }
  if (!isValidEmail(input.email)) {
    errors.email = 'Enter a valid email address.';
  }
  if (
    input.password.length < 8 ||
    !/[A-Za-z]/.test(input.password) ||
    !/\d/.test(input.password)
  ) {
    errors.password = 'Use at least 8 characters with a letter and a number.';
  }
  if (input.confirm !== input.password) {
    errors.confirm = 'Passwords do not match.';
  }
  if (!input.role || !REGISTRABLE_ROLES.includes(input.role)) {
    errors.role = 'Choose Teacher or Student.';
  }
  return errors;
}
