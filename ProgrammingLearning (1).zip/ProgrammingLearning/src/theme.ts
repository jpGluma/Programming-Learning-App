export const colors = {
  bg: '#0E1A2B',
  surface: '#162840',
  border: '#25405F',
  text: '#EAF1FB',
  muted: '#8EA3BF',
  accent: '#FFB547',
  accentText: '#1B1203',
  danger: '#FF8A8A',
  ok: '#5EEAD4',
};

export const radius = { sm: 8, md: 12, lg: 18 };
