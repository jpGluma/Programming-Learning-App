export const LANGUAGES = ['Java', 'Python', 'C++', 'JavaScript', 'PHP'];
