import React from 'react';
import { ScrollView, StyleSheet, Text, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useAuth } from '../auth/AuthContext';
import { ROLE_LABEL } from '../rules';
import { colors } from '../theme';
import { Button } from './Button';

export function RoleScreen({ children }: { children: React.ReactNode }) {
  const { user, logout } = useAuth();
  if (!user) return null;
  return (
    <SafeAreaView style={styles.safe}>
      <ScrollView contentContainerStyle={styles.body}>
        <View style={styles.header}>
          <Text style={styles.role}>{ROLE_LABEL[user.role]}</Text>
          <Text style={styles.name}>Hello, {user.name}</Text>
          <Text style={styles.email}>{user.email}</Text>
        </View>
        {children}
        <View style={{ marginTop: 24 }}>
          <Button title="Sign out" variant="ghost" onPress={logout} />
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

export const cardStyles = StyleSheet.create({
  card: {
    backgroundColor: colors.surface,
    borderColor: colors.border,
    borderWidth: 1,
    borderRadius: 14,
    padding: 16,
    marginBottom: 12,
  },
  title: { color: colors.text, fontSize: 16, fontWeight: '700', marginBottom: 4 },
  text: { color: colors.muted, fontSize: 14, lineHeight: 20 },
});

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: colors.bg },
  body: { padding: 20 },
  header: { marginBottom: 20 },
  role: { color: colors.accent, fontSize: 14, fontWeight: '700' },
  name: { color: colors.text, fontSize: 26, fontWeight: '800', marginTop: 4 },
  email: { color: colors.muted, fontSize: 14, marginTop: 2 },
});
