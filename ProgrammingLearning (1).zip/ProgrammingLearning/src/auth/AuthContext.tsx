import AsyncStorage from '@react-native-async-storage/async-storage';
import * as Crypto from 'expo-crypto';
import React, {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
} from 'react';
import {
  REGISTRABLE_ROLES,
  RegisterInput,
  Role,
  isValidEmail,
  validateRegistration,
} from '../rules';

export type User = {
  id: string;
  name: string;
  email: string;
  role: Role;
  passwordHash: string;
  createdAt: number;
};

type Result = { ok: true } | { ok: false; error: string };

type AuthValue = {
  ready: boolean;
  user: User | null;
  users: User[];
  login: (email: string, password: string) => Promise<Result>;
  register: (input: RegisterInput) => Promise<Result>;
  logout: () => Promise<void>;
};

// Built-in admin account. Change these before you ship.
export const BUILT_IN_ADMIN = {
  name: 'System Admin',
  email: 'admin@programming.edu',
  password: 'Admin@123',
};

const USERS_KEY = 'pl:users';
const SESSION_KEY = 'pl:session';

const hash = (email: string, password: string) =>
  Crypto.digestStringAsync(
    Crypto.CryptoDigestAlgorithm.SHA256,
    `pl-salt:${email.trim().toLowerCase()}:${password}`,
  );

const AuthContext = createContext<AuthValue | null>(null);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [ready, setReady] = useState(false);
  const [users, setUsers] = useState<User[]>([]);
  const [userId, setUserId] = useState<string | null>(null);

  useEffect(() => {
    (async () => {
      try {
        const raw = await AsyncStorage.getItem(USERS_KEY);
        let list: User[] = raw ? JSON.parse(raw) : [];

        // Seed the built-in admin the first time the app runs.
        if (!list.some((u) => u.role === 'admin')) {
          list = [
            {
              id: 'admin-builtin',
              name: BUILT_IN_ADMIN.name,
              email: BUILT_IN_ADMIN.email,
              role: 'admin',
              passwordHash: await hash(BUILT_IN_ADMIN.email, BUILT_IN_ADMIN.password),
              createdAt: Date.now(),
            },
            ...list,
          ];
          await AsyncStorage.setItem(USERS_KEY, JSON.stringify(list));
        }

        const session = await AsyncStorage.getItem(SESSION_KEY);
        setUsers(list);
        if (session && list.some((u) => u.id === session)) setUserId(session);
      } finally {
        setReady(true);
      }
    })();
  }, []);

  const login = useCallback<AuthValue['login']>(
    async (email, password) => {
      if (!isValidEmail(email) || !password) {
        return { ok: false, error: 'Enter your email and password.' };
      }
      const found = users.find(
        (u) => u.email.toLowerCase() === email.trim().toLowerCase(),
      );
      const attempt = await hash(email, password);
      if (!found || found.passwordHash !== attempt) {
        return { ok: false, error: 'Email or password is incorrect.' };
      }
      await AsyncStorage.setItem(SESSION_KEY, found.id);
      setUserId(found.id);
      return { ok: true };
    },
    [users],
  );

  const register = useCallback<AuthValue['register']>(
    async (input) => {
      const errors = validateRegistration(input);
      const first = Object.values(errors)[0];
      if (first) return { ok: false, error: first };

      // Rule: admin can never be created through registration.
      if (!input.role || !REGISTRABLE_ROLES.includes(input.role)) {
        return { ok: false, error: 'Choose Teacher or Student.' };
      }
      const email = input.email.trim().toLowerCase();
      if (users.some((u) => u.email.toLowerCase() === email)) {
        return { ok: false, error: 'An account with this email already exists.' };
      }

      const newUser: User = {
        id: `u-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
        name: input.name.trim(),
        email,
        role: input.role,
        passwordHash: await hash(email, input.password),
        createdAt: Date.now(),
      };
      const next = [...users, newUser];
      await AsyncStorage.multiSet([
        [USERS_KEY, JSON.stringify(next)],
        [SESSION_KEY, newUser.id],
      ]);
      setUsers(next);
      setUserId(newUser.id);
      return { ok: true };
    },
    [users],
  );

  const logout = useCallback(async () => {
    await AsyncStorage.removeItem(SESSION_KEY);
    setUserId(null);
  }, []);

  const user = users.find((u) => u.id === userId) ?? null;

  const value = useMemo(
    () => ({ ready, user, users, login, register, logout }),
    [ready, user, users, login, register, logout],
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used inside AuthProvider');
  return ctx;
}
