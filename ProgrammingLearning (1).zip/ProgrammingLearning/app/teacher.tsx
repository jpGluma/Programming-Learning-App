import React from 'react';
import { Text, View } from 'react-native';
import { RoleScreen, cardStyles as c } from '../src/components/RoleScreen';
import { LANGUAGES } from '../src/data';

export default function TeacherHome() {
  return (
    <RoleScreen>
      <View style={c.card}>
        <Text style={c.title}>Your lessons</Text>
        <Text style={c.text}>
          Upload lessons with explanations and examples for each language. Lesson upload comes next.
        </Text>
      </View>
      <View style={c.card}>
        <Text style={c.title}>Languages</Text>
        <Text style={c.text}>{LANGUAGES.join(', ')}</Text>
      </View>
    </RoleScreen>
  );
}
