import React from 'react';
import { Text, View } from 'react-native';
import { useAuth } from '../src/auth/AuthContext';
import { RoleScreen, cardStyles as c } from '../src/components/RoleScreen';
import { ROLE_LABEL } from '../src/rules';

export default function AdminHome() {
  const { users } = useAuth();
  const teachers = users.filter((u) => u.role === 'teacher').length;
  const students = users.filter((u) => u.role === 'student').length;

  return (
    <RoleScreen>
      <View style={c.card}>
        <Text style={c.title}>Overview</Text>
        <Text style={c.text}>
          {teachers} teacher{teachers === 1 ? '' : 's'} and {students} student
          {students === 1 ? '' : 's'} registered.
        </Text>
      </View>
      <Text style={[c.title, { marginTop: 8, marginBottom: 8 }]}>All users</Text>
      {users.map((u) => (
        <View key={u.id} style={c.card}>
          <Text style={c.title}>{u.name}</Text>
          <Text style={c.text}>
            {u.email} · {ROLE_LABEL[u.role]}
          </Text>
        </View>
      ))}
    </RoleScreen>
  );
}
