import { Link } from 'expo-router';
import React, { useState } from 'react';
import {
  KeyboardAvoidingView,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useAuth } from '../src/auth/AuthContext';
import { Button } from '../src/components/Button';
import { Field } from '../src/components/Field';
import {
  REGISTRABLE_ROLES,
  ROLE_LABEL,
  RegisterErrors,
  RegistrableRole,
  validateRegistration,
} from '../src/rules';
import { colors, radius } from '../src/theme';

const ROLE_HINT: Record<RegistrableRole, string> = {
  teacher: 'Upload and manage programming lessons.',
  student: 'Learn languages and track your progress.',
};

export default function Register() {
  const { register } = useAuth();
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirm, setConfirm] = useState('');
  const [role, setRole] = useState<RegistrableRole | null>(null);
  const [errors, setErrors] = useState<RegisterErrors>({});
  const [formError, setFormError] = useState('');
  const [busy, setBusy] = useState(false);

  const submit = async () => {
    setFormError('');
    const input = { name, email, password, confirm, role };
    const found = validateRegistration(input);
    setErrors(found);
    if (Object.keys(found).length) return;

    setBusy(true);
    const res = await register(input);
    setBusy(false);
    // On success the route guards move the user to their role's home screen.
    if (!res.ok) setFormError(res.error);
  };

  return (
    <SafeAreaView style={styles.safe}>
      <KeyboardAvoidingView
        style={{ flex: 1 }}
        behavior={Platform.OS === 'ios' ? 'padding' : undefined}
      >
        <ScrollView contentContainerStyle={styles.body} keyboardShouldPersistTaps="handled">
          <Text style={styles.title}>Create account</Text>
          <Text style={styles.sub}>Pick your role, then fill in your details.</Text>

          <Text style={styles.label}>I am a</Text>
          <View style={styles.roles}>
            {REGISTRABLE_ROLES.map((r) => {
              const active = role === r;
              return (
                <Pressable
                  key={r}
                  onPress={() => setRole(r)}
                  style={[styles.role, active && styles.roleActive]}
                >
                  <Text style={[styles.roleName, active && { color: colors.accent }]}>
                    {ROLE_LABEL[r]}
                  </Text>
                  <Text style={styles.roleHint}>{ROLE_HINT[r]}</Text>
                </Pressable>
              );
            })}
          </View>
          {errors.role ? <Text style={styles.error}>{errors.role}</Text> : null}

          <View style={{ marginTop: 18 }}>
            <Field label="Full name" value={name} onChangeText={setName} error={errors.name} autoComplete="name" />
            <Field
              label="Email"
              value={email}
              onChangeText={setEmail}
              error={errors.email}
              autoCapitalize="none"
              keyboardType="email-address"
              autoComplete="email"
            />
            <Field
              label="Password"
              value={password}
              onChangeText={setPassword}
              error={errors.password}
              secure
              autoCapitalize="none"
              placeholder="8+ characters, letter and number"
            />
            <Field
              label="Confirm password"
              value={confirm}
              onChangeText={setConfirm}
              error={errors.confirm}
              secure
              autoCapitalize="none"
              onSubmitEditing={submit}
            />
            {formError ? <Text style={[styles.error, { marginBottom: 12 }]}>{formError}</Text> : null}
            <Button title="Create account" onPress={submit} loading={busy} />
          </View>

          <View style={styles.footer}>
            <Text style={styles.sub}>Already registered? </Text>
            <Link href="/login" style={styles.link}>
              Sign in
            </Link>
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: colors.bg },
  body: { padding: 24, paddingTop: 36 },
  title: { color: colors.text, fontSize: 32, fontWeight: '800' },
  sub: { color: colors.muted, fontSize: 15, marginTop: 6 },
  label: { color: colors.text, fontSize: 14, fontWeight: '600', marginTop: 24, marginBottom: 8 },
  roles: { flexDirection: 'row', gap: 12 },
  role: {
    flex: 1,
    backgroundColor: colors.surface,
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: radius.md,
    padding: 14,
  },
  roleActive: { borderColor: colors.accent },
  roleName: { color: colors.text, fontSize: 17, fontWeight: '700' },
  roleHint: { color: colors.muted, fontSize: 13, marginTop: 4, lineHeight: 18 },
  error: { color: colors.danger, fontSize: 13, marginTop: 6 },
  footer: { flexDirection: 'row', justifyContent: 'center', marginTop: 28, flexWrap: 'wrap' },
  link: { color: colors.accent, fontSize: 15, fontWeight: '700', marginTop: 6 },
});
