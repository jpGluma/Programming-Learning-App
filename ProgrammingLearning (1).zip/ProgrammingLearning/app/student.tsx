import React, { useState } from 'react';
import { Pressable, Text, View } from 'react-native';
import { RoleScreen, cardStyles as c } from '../src/components/RoleScreen';
import { LANGUAGES } from '../src/data';
import { colors } from '../src/theme';

export default function StudentHome() {
  const [lang, setLang] = useState<string | null>(null);
  return (
    <RoleScreen>
      <Text style={[c.title, { marginBottom: 10 }]}>Choose a programming language</Text>
      <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 10, marginBottom: 16 }}>
        {LANGUAGES.map((l) => {
          const active = lang === l;
          return (
            <Pressable
              key={l}
              onPress={() => setLang(l)}
              style={{
                paddingVertical: 10,
                paddingHorizontal: 16,
                borderRadius: 999,
                borderWidth: 1,
                borderColor: active ? colors.accent : colors.border,
                backgroundColor: colors.surface,
              }}
            >
              <Text style={{ color: active ? colors.accent : colors.text, fontWeight: '600' }}>{l}</Text>
            </Pressable>
          );
        })}
      </View>
      <View style={c.card}>
        <Text style={c.title}>{lang ? `${lang} lessons` : 'Lessons'}</Text>
        <Text style={c.text}>
          {lang ? 'Lessons will appear here once your teachers upload them.' : 'Select a language to see its lessons.'}
        </Text>
      </View>
      <View style={c.card}>
        <Text style={c.title}>Your progress</Text>
        <Text style={c.text}>0 lessons completed.</Text>
      </View>
    </RoleScreen>
  );
}
