import { Redirect } from 'expo-router';
import { useAuth } from '../src/auth/AuthContext';
import { ROLE_HOME } from '../src/rules';

export default function Index() {
  const { user } = useAuth();
  return <Redirect href={user ? ROLE_HOME[user.role] : '/login'} />;
}
