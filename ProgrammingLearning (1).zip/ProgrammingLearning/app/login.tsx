import { Link } from 'expo-router';
import React, { useState } from 'react';
import { KeyboardAvoidingView, Platform, ScrollView, StyleSheet, Text, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useAuth } from '../src/auth/AuthContext';
import { Button } from '../src/components/Button';
import { Field } from '../src/components/Field';
import { colors } from '../src/theme';

export default function Login() {
  const { login } = useAuth();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);

  const submit = async () => {
    setError('');
    setBusy(true);
    const res = await login(email, password);
    setBusy(false);
    // On success the route guards move the user to their role's home screen.
    if (!res.ok) setError(res.error);
  };

  return (
    <SafeAreaView style={styles.safe}>
      <KeyboardAvoidingView
        style={{ flex: 1 }}
        behavior={Platform.OS === 'ios' ? 'padding' : undefined}
      >
        <ScrollView contentContainerStyle={styles.body} keyboardShouldPersistTaps="handled">
          <Text style={styles.brand}>Programming Learning</Text>
          <Text style={styles.title}>Sign in</Text>
          <Text style={styles.sub}>
            Admins, teachers and students all sign in here.
          </Text>

          <View style={{ marginTop: 28 }}>
            <Field
              label="Email"
              value={email}
              onChangeText={setEmail}
              autoCapitalize="none"
              keyboardType="email-address"
              autoComplete="email"
              placeholder="you@example.com"
            />
            <Field
              label="Password"
              value={password}
              onChangeText={setPassword}
              secure
              autoCapitalize="none"
              placeholder="Your password"
              onSubmitEditing={submit}
            />
            {error ? <Text style={styles.error}>{error}</Text> : null}
            <Button title="Sign in" onPress={submit} loading={busy} />
          </View>

          <View style={styles.footer}>
            <Text style={styles.sub}>New teacher or student? </Text>
            <Link href="/register" style={styles.link}>
              Create an account
            </Link>
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: colors.bg },
  body: { padding: 24, paddingTop: 48 },
  brand: { color: colors.accent, fontSize: 15, fontWeight: '700' },
  title: { color: colors.text, fontSize: 34, fontWeight: '800', marginTop: 8 },
  sub: { color: colors.muted, fontSize: 15, marginTop: 6 },
  error: { color: colors.danger, marginBottom: 12, fontSize: 14 },
  footer: { flexDirection: 'row', justifyContent: 'center', marginTop: 28, flexWrap: 'wrap' },
  link: { color: colors.accent, fontSize: 15, fontWeight: '700', marginTop: 6 },
});
